# fraud_streaming.py
from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StructField, DoubleType, IntegerType

# Initialize Spark Session with Scala compatibility settings
spark = SparkSession.builder \
    .appName("FraudDetection") \
    .config("spark.sql.streaming.schemaInference", "true") \
    .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer") \
    .config("spark.kryo.registrationRequired", "false") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")

# Define schema for incoming JSON
schema = StructType([
    StructField("amount", DoubleType(), True),
    StructField("spending_deviation_score", DoubleType(), True),
    StructField("velocity_score", DoubleType(), True),
    StructField("geo_anomaly_score", DoubleType(), True),
    StructField("is_fraud", IntegerType(), True)
])

# Read from Kafka
df_raw = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "kafka-broker:9092") \
    .option("subscribe", "fraud-transactions") \
    .option("startingOffsets", "latest") \
    .load()

# Parse JSON from Kafka value (the 'value' field contains your transaction JSON)
df_parsed = df_raw.select(
    from_json(col("value").cast("string"), schema).alias("data")
).select("data.*")

# Define these as broadcast variables or load inside the function
MODEL_PATH = "/app/fraud_lr_model"
FEATURE_COLS = ["amount", "spending_deviation_score", "velocity_score", "geo_anomaly_score"]

def predict_batch(df, epoch_id):
    """
    Process each micro-batch of streaming data
    """
    if df.isEmpty():
        print(f"Epoch {epoch_id}: Empty batch, skipping...")
        return
    
    try:
        print(f"\n=== Processing Epoch {epoch_id} ===")
        
        # Load model and assembler INSIDE the function (fixes serialization)
        from pyspark.ml.classification import LogisticRegressionModel
        from pyspark.ml.feature import VectorAssembler
        
        lr_model = LogisticRegressionModel.load(MODEL_PATH)
        assembler = VectorAssembler(
            inputCols=FEATURE_COLS,
            outputCol="features"
        )
        
        # Check for null values
        null_counts = df.select([col(c).isNull().cast("int").alias(c) for c in df.columns])
        if null_counts.first():
            print("Warning: Null values detected")
            df = df.na.drop()  # Drop rows with nulls
        
        # Assemble features
        df_features = assembler.transform(df)
        
        # Predict
        predictions = lr_model.transform(df_features)
        
        # Show predictions
        predictions.select(
            "amount",
            "spending_deviation_score", 
            "velocity_score",
            "geo_anomaly_score",
            "is_fraud",
            "prediction",
            "probability"
        ).show(truncate=False)
        
        # Optional: Calculate accuracy if ground truth exists
        correct = predictions.filter(col("is_fraud") == col("prediction")).count()
        total = predictions.count()
        accuracy = correct / total if total > 0 else 0
        print(f"Batch accuracy: {accuracy:.2%} ({correct}/{total})")
        
    except Exception as e:
        print(f"Error in epoch {epoch_id}: {str(e)}")
        import traceback
        traceback.print_exc()

# Start streaming query with proper error handling
try:
    query = df_parsed.writeStream \
        .foreachBatch(predict_batch) \
        .option("checkpointLocation", "/tmp/checkpoint") \
        .trigger(processingTime='5 seconds') \
        .start()
    
    print("Streaming query started. Waiting for data...")
    print(f"Query ID: {query.id}")
    print(f"Status: {query.status}")
    
    query.awaitTermination()
    
except KeyboardInterrupt:
    print("\nStopping query...")
    query.stop()
    print("Query stopped successfully")
except Exception as e:
    print(f"Stream failed: {e}")
    import traceback
    traceback.print_exc()
finally:
    spark.stop()