from pyspark.sql import SparkSession, functions as F
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.classification import LogisticRegression
import sys

# Create SparkSession with Spark 4.0.1 optimized settings
spark = (
    SparkSession.builder
    .appName("Fraud_LR_Weighted")
    .config("spark.sql.shuffle.partitions", "8")
    .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    .getOrCreate()
)

print(f"Using Spark version: {spark.version}")
print(f"Using Scala version: {spark.sparkContext._jvm.scala.util.Properties.versionString()}")

try:
    # Load dataset from HDFS
    hdfs_path = "hdfs://namenode:8020/training_data/modified_fraud_dataset.csv"
    print(f"\nLoading data from: {hdfs_path}")
    
    df = (
        spark.read
        .option("header", "true")
        .option("inferSchema", "true")
        .csv(hdfs_path)
    )
    
    print(f"Loaded {df.count()} records")
    df.printSchema()
    
    # Convert labels to 0 and 1 (0 for nonfraud and 1 for fraud)
    df_model = df.withColumn("label", F.col("is_fraud").cast("int"))
    
    # Calculate weight for each class to help with the imbalance
    fraud_count = df_model.filter(F.col("label") == 1).count()
    nonfraud_count = df_model.filter(F.col("label") == 0).count()
    
    print(f"\nClass distribution:")
    print(f"  Fraud cases: {fraud_count}")
    print(f"  Non-fraud cases: {nonfraud_count}")
    print(f"  Imbalance ratio: 1:{nonfraud_count/fraud_count:.1f}")
    
    if fraud_count == 0 or nonfraud_count == 0:
        print("ERROR: One class has zero samples. Cannot train model.")
        sys.exit(1)
    
    majority = max(fraud_count, nonfraud_count)
    fraud_weight = majority / float(fraud_count)
    nonfraud_weight = majority / float(nonfraud_count)
    
    print(f"\nClass weights:")
    print(f"  Fraud weight: {fraud_weight:.4f}")
    print(f"  Non-fraud weight: {nonfraud_weight:.4f}")
    
    # Add the weight column to df based on label
    df_weighted = df_model.withColumn(
        "weight",
        F.when(F.col("label") == 1, F.lit(fraud_weight))
        .otherwise(F.lit(nonfraud_weight))
    )
    
    # Choose features (numeric)
    feature_cols = [
        "amount",
        "spending_deviation_score",
        "velocity_score",
        "geo_anomaly_score"
    ]
    
    assembler = VectorAssembler(
        inputCols=feature_cols,
        outputCol="features",
        handleInvalid="keep"
    )
    
    df_vector = assembler.transform(df_weighted).select("features", "label", "weight")
    
    # Check for null values
    null_count = df_vector.filter(
        F.col("features").isNull() | F.col("label").isNull()
    ).count()
    
    if null_count > 0:
        print(f"WARNING: Found {null_count} rows with null values, dropping them")
        df_vector = df_vector.na.drop()
    
    # Split data (90/10) for train/test
    train_df, test_df = df_vector.randomSplit([0.9, 0.1], seed=42)
    
    train_count = train_df.count()
    test_count = test_df.count()
    print(f"\nData split:")
    print(f"  Training set: {train_count} records")
    print(f"  Test set: {test_count} records")
    
    # Train logistic regression model
    print("\nTraining model...")
    lr = LogisticRegression(
        featuresCol="features",
        labelCol="label",
        weightCol="weight",
        maxIter=20,
        regParam=0.0,
        elasticNetParam=0.0
    )
    
    lr_model = lr.fit(train_df)
    print("✓ Model training completed")
    
    # Save model (overwrites existing)
    model_path = "/app/fraud_lr_model"
    print(f"\nSaving model to: {model_path}")
    lr_model.write().overwrite().save(model_path)
    print("✓ Model saved successfully")
    
    # Get predictions on test set
    print("\nEvaluating model on test set...")
    predictions = lr_model.transform(test_df).select("label", "prediction").cache()
    
    # Model metrics
    preds = predictions.select(
        F.col("label").cast("int").alias("label"),
        F.col("prediction").cast("int").alias("prediction")
    )
    
    # Confusion matrix
    true_pos = preds.filter((F.col("label") == 1) & (F.col("prediction") == 1)).count()
    true_neg = preds.filter((F.col("label") == 0) & (F.col("prediction") == 0)).count()
    false_pos = preds.filter((F.col("label") == 0) & (F.col("prediction") == 1)).count()
    false_neg = preds.filter((F.col("label") == 1) & (F.col("prediction") == 0)).count()
    
    total = true_pos + true_neg + false_pos + false_neg
    
    if total > 0:
        accuracy = (true_pos + true_neg) / total
    else:
        accuracy = 0.0
    
    if (true_pos + false_pos) > 0:
        precision_fraud = true_pos / (true_pos + false_pos)
    else:
        precision_fraud = 0.0
    
    if (true_pos + false_neg) > 0:
        recall_fraud = true_pos / (true_pos + false_neg)
    else:
        recall_fraud = 0.0
    
    if (precision_fraud + recall_fraud) > 0:
        f1_fraud = 2 * (precision_fraud * recall_fraud) / (precision_fraud + recall_fraud)
    else:
        f1_fraud = 0.0
    
    print("\n" + "="*50)
    print("CONFUSION MATRIX")
    print("="*50)
    print(f"True Positives  (fraud → fraud):     {true_pos:>6}")
    print(f"False Negatives (fraud → non-fraud): {false_neg:>6}")
    print(f"False Positives (non-fraud → fraud): {false_pos:>6}")
    print(f"True Negatives  (non-fraud → non-fraud): {true_neg:>6}")
    
    print("\n" + "="*50)
    print("METRICS")
    print("="*50)
    print(f"Accuracy:           {accuracy:.4f} ({accuracy*100:.2f}%)")
    print(f"Precision (fraud):  {precision_fraud:.4f}")
    print(f"Recall (fraud):     {recall_fraud:.4f}")
    print(f"F1-score (fraud):   {f1_fraud:.4f}")
    print("="*50)
    
    print("\n✓ Training pipeline completed successfully!")
    
except Exception as e:
    print(f"\n✗ ERROR: {str(e)}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
finally:
    spark.stop()