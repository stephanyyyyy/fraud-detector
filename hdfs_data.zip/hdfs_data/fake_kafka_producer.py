# fake_kafka_producer.py
from kafka import KafkaProducer
import json
import random
import time

# Kafka broker (replace with your broker if different)
BROKER = "kafka-broker:9092"
TOPIC = "fraud-transactions"

producer = KafkaProducer(
    bootstrap_servers=[BROKER],
    value_serializer=lambda v: json.dumps(v).encode("utf-8")
)

def generate_fake_transaction():
    """
    Generates a fake transaction record with features similar to your model.
    """
    return {
        "amount": round(random.uniform(1, 1000), 2),
        "spending_deviation_score": round(random.uniform(0, 10), 2),
        "velocity_score": round(random.uniform(0, 10), 2),
        "geo_anomaly_score": round(random.uniform(0, 10), 2),
        "is_fraud": random.choices([0, 1], weights=[95, 5])[0]  # mostly non-fraud
    }

if __name__ == "__main__":
    while True:
        txn = generate_fake_transaction()
        producer.send(TOPIC, value=txn)
        print(f"Sent: {txn}")
        time.sleep(1)  # send 1 txn per second (adjust as needed)
